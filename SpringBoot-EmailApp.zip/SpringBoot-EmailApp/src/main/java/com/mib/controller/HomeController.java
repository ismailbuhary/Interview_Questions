package com.mib.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mib.domain.Feedback;
import com.mib.domain.Person;
import com.mib.service.IEmailService;

@Controller
public class HomeController {

	@Autowired
	private IEmailService emailService;
	
	@RequestMapping("/home")
	public String home(Model model) {
		
		Person person =new Person();
		person.setFirstName("Lee1");
		person.setEmail("mbuhary@gmail.com");
		model.addAttribute("person",person);
	
		return "home";
	}
	
	@RequestMapping(value="/home",method=RequestMethod.POST)
	public void homePost(@ModelAttribute("person") Person person) {
		
		System.out.println(person.getFirstName());
	}
	
	@RequestMapping(value="/contact")
	public String contact(Model model){
		Feedback feedback = new Feedback();
		model.addAttribute("feedback",feedback);
		return "contact";
	}
	
	@RequestMapping(value="/contact",method=RequestMethod.POST)
	public String contactPost(@ModelAttribute("feedback") Feedback feedback) {
		
		System.out.println(feedback.getFirstName());
		emailService.sendFeedbackEmail(feedback);
		return "contact";
		
	}
	
	
	
	
	
		
		@GetMapping("/index")
		public String getInternationalPage() {
			return "index" ;
		}
		

	
	
	@RequestMapping("/homeone")
	public ModelAndView homeOne(ModelAndView modelAndView) {
		
		Person person =new Person();
		person.setFirstName("Lee");
		person.setEmail("buhary@gmail.com");
		modelAndView.addObject("person",person);
		modelAndView.setViewName("index");
		
		return modelAndView;
	}

}
