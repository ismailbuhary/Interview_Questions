package com.mib.domain;

import java.io.Serializable;

import javassist.SerialVersionUID;

public class Feedback implements Serializable {
	
	   public static final long serialVersionUID =11255L;
	   
	   private String firstName;
	   private String email;
	   private String message;
	   
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	   
	   

}
