package com.mib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymleafDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymleafDemoApplication.class, args);
	}
}
