package com.mib.service;

import org.springframework.mail.SimpleMailMessage;

import com.mib.domain.Feedback;

public interface IEmailService {
	

	
	
	void sendFeedbackEmail(Feedback feedback);
	void sendGenericEmailMessage(SimpleMailMessage massage);
	

}
