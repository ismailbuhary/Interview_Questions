package com.mib.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

public class BaseEmailService extends AbstractEmailService {

	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(BaseEmailService.class);

	
	@Autowired
	public MailSender mailSend;
	
	@Override
	public void sendGenericEmailMessage(SimpleMailMessage message) {
		// TODO Auto-generated method stub
		
	    LOG.debug("sending email for {}",message);
		mailSend.send(message);
		System.out.println("Email Sent");
		
		
		
	}

}
