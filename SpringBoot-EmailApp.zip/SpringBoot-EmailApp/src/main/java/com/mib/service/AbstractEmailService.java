package com.mib.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

import com.mib.domain.Feedback;

public abstract class AbstractEmailService implements IEmailService{
	
	private static final org.slf4j.Logger LOG = org.slf4j.LoggerFactory.getLogger(AbstractEmailService.class);


	
	protected SimpleMailMessage prepareSimpleMailMessageFromFeedback(Feedback feedback){
		
/*		MimeMessage message =mailSend.createMimeMessage();
		MimeMessageHelper helper= new MimeMessageHelper(message);*/
		SimpleMailMessage helper = new SimpleMailMessage();
		helper.setTo("buhary55@gmail.com");
		helper.setFrom(feedback.getEmail());
		helper.setSubject("Feedback received from"+feedback.getFirstName()+"using email :"+feedback.getEmail()+"!");
		helper.setText(feedback.getMessage());
		
		return helper;
	}
	
	
	
	@Override
	public void sendFeedbackEmail(Feedback feedback) {
		// TODO Auto-generated method stub
	
			sendGenericEmailMessage(prepareSimpleMailMessageFromFeedback(feedback));
	
		
	}
		
		


}
